#!/usr/bin/python3
# -*- coding:utf-8 -*-
from django.apps import AppConfig


class DemoConfig(AppConfig):
    name = 'demo'
    verbose_name = "配置"

    orderIndex_=1